export default function Footer() {
    return <footer id="footer" className="footer">
    <div className="copyright">
      &copy; Copyright <strong><span>KMG</span></strong>. All Rights Reserved
    </div>
  </footer>
  }